# DDoS-Scripts
Diversi Script installabili e utilizzabili su Server Linux (Spoof e non) per poter fare attacchi DDoS

ATTENZIONE: Non mi assumo nessuna responsabilità nell'uso che ne farete di questi Scripts. Fate tutto a vostro rischio e pericolo.
